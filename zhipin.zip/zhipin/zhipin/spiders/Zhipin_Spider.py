# -*- coding:utf-8 -*-
import scrapy
import sys
reload(sys)
import time
from zhipin.items import CrawlbosszhipinItem
sys.setdefaultencoding("utf-8")

class ZhipinSpider(scrapy.Spider):
    # name: 用于区别Spider。 该名字必须是唯一的，您不可以为不同的Spider设定相同的名字。
    name = 'zhipin'
    curPage = 0
    allowed_domain = ['www.zhipin.com']
    start_urls = ['http://www.zhipin.com/c101280100-p100301/']
    url = 'http://www.zhipin.com/'
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'zh-CN,zh;q=0.8',
        'cookie': 'lastCity=101280100; __c=1532521800; __g=-; toUrl=https%3A%2F%2Fwww.zhipin.com%2Fc101280100-p100301%2F; JSESSIONID=""; __l=l=%2Fwww.zhipin.com%2Fjob_detail%2F4b81804a0701259f1Xd_3di1F1M~.html&r=; __a=3452363.1532422694.1532422768.1532521800.36.3.5.36; Hm_lvt_194df3105ad7148dcf2b98a91b5e727a=1532483057,1532483762,1532483775,1532521800; Hm_lpvt_194df3105ad7148dcf2b98a91b5e727a=1532576530',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36'
    }

    def parse(self, response):
        print("request -> " + response.url)
        job_list = response.css('div.job-list > ul > li')
        for job in job_list:
            item = CrawlbosszhipinItem()
            job_primary = job.css('div.job-primary')
            # 职位详情ID
            item['jid'] = job_primary.css('div.info-primary > h3 > a::attr(data-jid)').extract_first().strip()
            # 职位名称
            item["jobName"] = job_primary.css('div.info-primary > h3 > a > div.job-title::text').extract_first().strip()
            # 薪水
            item["salary"] = job_primary.css('div.info-primary > h3 > a > span.red::text').extract_first().strip()

            info_primary = job_primary.css('div.info-primary > p::text').extract()
            # 城市
            item['city'] = info_primary[0].strip()
            # 工作年限
            item['workYear'] = info_primary[1].strip()
            # 教育水平
            item['education'] = info_primary[2].strip()
            # 企业简称
            item['companyShortName'] = job_primary.css('div.info-company > div.company-text > h3 > a::text').extract_first().strip()

            company_infos = job_primary.css('div.info-company > div.company-text > p::text').extract()
            # 有一条招聘这里只有两项，所以加个判断
            if len(company_infos) == 3:
                # 公司总部
                item['industryField'] = company_infos[0].strip()
                # 公司等级
                item['financeStage'] = company_infos[1].strip()
                # 公司规模
                item['companySize'] = company_infos[2].strip()
            # 何时发布
            item['updated_at'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            yield scrapy.Request(self.url + ('job_detail/%s.html' % (item['jid'])), meta={'item': item}, callback=self.pare_detail, dont_filter=True)

    def pare_detail(self, response):
        item = response.meta['item']
        item['responsibility'] = ','.join(response.css('.job-sec > div.text::text').extract()).strip()
        item['address'] = response.css('.location-address::text').extract_first().strip()

        yield item

        # 选取要爬的页数
        if self.curPage < 20:
            self.curPage += 1
        # 每爬一条睡10s，免得被封
        time.sleep(10)
        # 接着来爬下一页的数据
        yield scrapy.Request(self.start_urls[0] +
                             ('?page=%d&ka=page-next' % (self.curPage)), callback=self.parse)









