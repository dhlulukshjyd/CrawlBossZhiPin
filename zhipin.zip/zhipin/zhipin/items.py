# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class CrawlbosszhipinItem(scrapy.Item):
    jid = scrapy.Field()
    jobName = scrapy.Field()
    jobLables = scrapy.Field()
    workYear = scrapy.Field()
    salary = scrapy.Field()
    city = scrapy.Field()
    education = scrapy.Field()
    companyShortName = scrapy.Field()
    industryField = scrapy.Field()
    financeStage = scrapy.Field()
    companySize = scrapy.Field()
    responsibility = scrapy.Field()
    address = scrapy.Field()
    updated_at = scrapy.Field()